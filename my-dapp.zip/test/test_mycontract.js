const MyContract = artifacts.require("MyContract");

contract("MyContract", (accounts) => {
  it("should deploy the contract", async () => {
    const instance = await MyContract.deployed();
    const message = await instance.message();
    assert.equal(message, "Hello, World!");
  });

  it("should update the message", async () => {
    const instance = await MyContract.deployed();
    await instance.updateMessage("New Message", { from: accounts[0] });
    const message = await instance.message();
    assert.equal(message, "New Message");
  });
});
