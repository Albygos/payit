const contractAddress = 'YOUR_DEPLOYED_CONTRACT_ADDRESS';
const contractABI = [...] // The ABI of your contract

let web3;
let contract;

window.onload = async () => {
  if (window.ethereum) {
    web3 = new Web3(window.ethereum);
    await window.ethereum.enable();
  } else {
    console.log('MetaMask not found');
  }

  contract = new web3.eth.Contract(contractABI, contractAddress);

  const message = await contract.methods.message().call();
  document.getElementById('message').innerText = message;
};

async function updateMessage() {
  const newMessage = document.getElementById('newMessage').value;
  const accounts = await web3.eth.getAccounts();
  await contract.methods.updateMessage(newMessage).send({ from: accounts[0] });
  const updatedMessage = await contract.methods.message().call();
  document.getElementById('message').innerText = updatedMessage;
}
